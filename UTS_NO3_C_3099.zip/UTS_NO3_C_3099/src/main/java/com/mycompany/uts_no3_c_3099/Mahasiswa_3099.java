/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.uts_no3_c_3099;

/**
 *
 * @author badnoby
 */
import java.io.BufferedReader;
public class Mahasiswa_3099 {
    String nim_3099, nama_3099, jurusan_3099;
    int ipk_3099;
    
    public void tampilDataMhs_3099() {
        System.out.println(" NIM    : " + nim_3099);
        System.out.println("Nama    " + nama_3099);
        System.out.println("Jurusan    : " + jurusan_3099);
        System.out.println("IPK : " + ipk_3099);
    }
}
