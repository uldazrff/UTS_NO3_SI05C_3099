/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.uts_no3_c_3099;

/**
 *
 * @author badnoby
 */
public class StudentStaff_3099 extends Mahasiswa_3099 {
    int jamKerja_3099;
    String unitKerja_3099;
    
    public double totalPendapatan_3099(){
        return (jamKerja_3099 * 30000);
    }
    public void tampilDataStudentStaff_3099(){
        super.tampilDataMhs_3099();
        System.out.println(" Unit Kerja : " + unitKerja_3099);
        System.out.println(" Jam Kerja : " +jamKerja_3099);
        System.out.println(" Total Pendapatan Student Staff : " +totalPendapatan_3099());
    }
}
